function Navigation() {
  return null;
}

export default Navigation;