function TreesIndex() {
  return null;
}

export default TreesIndex;