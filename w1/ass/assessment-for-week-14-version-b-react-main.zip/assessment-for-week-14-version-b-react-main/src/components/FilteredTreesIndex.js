import TreesIndex from './TreesIndex.js';

const FilteredTreesIndex = () => {
  return null;
}

export default FilteredTreesIndex;