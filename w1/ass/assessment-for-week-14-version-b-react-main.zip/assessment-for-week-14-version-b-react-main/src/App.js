import trees from "./mockData/trees.json";

function App() {
  return (
    <>
      <h1>Welcome to the Trees App</h1>
    </>
  );
}

export default App;