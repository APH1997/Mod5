import bulbasaur from './images/bulbasaur.jpg'
import "./Showcase.css"
function Showcase() {
  const favPokemon="Venasaur";
  const pokeCharacteristics = {};
  pokeCharacteristics.type = "Grass";
  pokeCharacteristics.move = "Cut";

  
  return (
    <div className="body">
      <h1>{favPokemon}'s Showcase Component</h1>
      <img src={bulbasaur} alt="This is not Venasaur" className="bulb"></img>
      <h2>{favPokemon} is a <span className="pokeType">{pokeCharacteristics.type}</span> type pokemon, and its best move is <span className="pokeMove">{pokeCharacteristics.move}</span>.</h2>
      
    </div>
  );
}

export default Showcase;