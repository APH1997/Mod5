import Showcase from './Showcase';
import "./App.css";
function App() {
  return (
    <div className="background">
      <Showcase />
    </div>
  );
}

export default App;
