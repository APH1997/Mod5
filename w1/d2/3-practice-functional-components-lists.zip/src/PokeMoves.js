import {moves} from "./data";
import PokeMoveCard from "./PokeMoveCard";

const PokeMoves = () => {

  return (
    <div>
      <h1>PokeMoves</h1>
      <ul>
        {moves.map(ele => (
          <PokeMoveCard key={ele.id} {...ele} />
        ))}
      </ul>
    </div>
  )
}

export default PokeMoves;