const FavoriteFruit = () => {
  return null;
}

export default FavoriteFruit;