function FruitShow() {
  return null;
}

export default FruitShow;