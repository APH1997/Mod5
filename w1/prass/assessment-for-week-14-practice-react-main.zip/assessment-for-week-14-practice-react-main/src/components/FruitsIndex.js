function FruitsIndex() {
  return null;
}

export default FruitsIndex;