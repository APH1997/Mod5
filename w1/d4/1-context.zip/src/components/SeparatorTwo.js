import Detail from "./Detail";

const SeparatorTwo = () => {
  return (
    <Detail />
  );
};

export default SeparatorTwo;
