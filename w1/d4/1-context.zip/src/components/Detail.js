import { useContext } from "react";
import { HoroscopeContext } from "../context/HoroscopeContext";

const Detail = () => {
  const horoscopeObj = useContext(HoroscopeContext);
  horoscopeObj.new = "is this new??";
  return (
    <div className="details">
      <img
        src="https://upload.wikimedia.org/wikipedia/commons/e/e1/FullMoon2010.jpg"
        alt=""
      />
      <h2>{horoscopeObj.sign}</h2>
      <h4>Element: {horoscopeObj.element}</h4>
      <h4>Traits: {horoscopeObj.trait}</h4>
    </div>
  );
};

export default Detail;
