import Detail from "./Detail";

const SeparatorTwo = () => {
  console.log("SeparatorTwo rendering");
  return <Detail />;
};

export default SeparatorTwo;
