const SideCard = () => {
  return (
    <div className='side-card'>
      <h1>React Context with Horoscopes</h1>
    </div>
  );
};

export default SideCard;
