import { createContext } from 'react';
import {useState} from 'react';
import horoscopeObj from '../data/horoscopes';

const HoroscopeProvider = props => {
  const [currentSign, setCurrentSign] = useState('Capricorn');
  const sign = horoscopeObj[currentSign];
  return (
    <HoroscopeContext.Provider value={{sign, setCurrentSign}}>
      {props.children}
    </HoroscopeContext.Provider>
  );
};



export default HoroscopeProvider;
export const HoroscopeContext = createContext();