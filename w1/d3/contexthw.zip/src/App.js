import PupForm from './components/PupForm';
import PupImage from './components/PupImage';

const App = () => (
  <div id="app">
    <PupForm />
    <PupImage />
  </div>
);

export default App;
